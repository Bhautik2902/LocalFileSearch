#include <stdio.h>
#include <stdlib.h>

// Function to find the maximum element and its index using pointers
void findMax(int *arr, int size, int *max, int *index) {
    // Your code goes here
    printf("ele: %d", (arr+0));   // arr[0] = *(arr+0)+
    printf("ele: %d", (arr+1));
    printf("ele: %d", (arr+2));
    printf("ele: %d", (arr+3));

    for (int i=0; i<size; i++) {
        if (*max < arr[i]) {
            *index = i;
            *max = arr[i];
        }
    }
}

// returning pointers.
int* findMax2(int *arr, int size) {
    int *max;
    int max_val = 0;
    max = &max_val;
    
    for (int i=0; i<size; i++) {
        if (*max < *(arr+i)) {
            *max = *(arr+i);
        }
    }
    return max;
}

int main() {
    int size;

    // Input the size of the array from the user
    printf("Enter the size of the array: ");
    scanf("%d", &size);

    int *arr = calloc(size, sizeof(int));

    // Input the elements of the array from the user
    printf("Enter the elements of the array:\n");
    for (int i = 0; i < size; i++) {
        printf("Element %d: ", i + 1);
        scanf("%d", &arr[i]);
    }

    //int max=0, index=0;
    // Call the findMax function to find the maximum element and its index using pointers
    int *max = findMax2(arr, size);

    // Display the maximum element and its index
    printf("Max element is: %d\n", *max);
    //printf("Max element index is: %d\n", index);

    return 0;
}
