#include <stdio.h>

void swap (int *a, int *b) {

    int temp = *a;
    *a = *b;
    *b = temp;
}

// Function to reverse the array using pointers
void reverseArray(int *arr, int size) {
    // Your code goes here
    printf("this is first element reference.: %d \n", arr);
    printf("this is first ele.: %d \n", *arr);

    int i=0, j=size-1;
    while (i < j) {
        //swap2(arr[i], arr[j]);
        swap((arr+i), (arr+j));
        i++;
        j--;
    }

    printf("After reverse: \nthis is first element reference.: %d \n", arr);
    printf("this is first ele.: %d \n", *arr);
}

int main() {
    int size;

    // Input the size of the array from the user
    printf("Enter the size of the array: ");
    scanf("%d", &size);

    int arr[size];

    // Input the elements of the array from the user
    printf("Enter the elements of the array:\n");
    for (int i = 0; i < size; i++) {
        printf("Element %d: ", i + 1);
        scanf("%d", &arr[i]);
    }

    // Call the reverseArray function to reverse the array using pointers
    reverseArray(arr, size);

    // Display the reversed array
    for (int i=0; i<size; i++) {
        printf("%d,", arr[i]);
    }
    return 0;
}

// substraction of pointers. generally (p2 - p1)/[size of datatype]
// substraction of pointers. in array (p2 - p1)