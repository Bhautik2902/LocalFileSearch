#include<stdio.h>

int main() {
    int *a;
    int arr[10];
    int *b;
    int *c;
    

    int a_ = 10, b_=20;
    a = &a_;
    b = &b_;

    printf("general sub: %d, %d, = %d\n",a, b, (b-a));
    printf("%d, %d\n", arr, arr+1);

    //printf("array sub %d", arr[10] )
}