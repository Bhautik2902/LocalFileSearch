#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>

void main() {
	umask(0000);
	int fd = open("sample.txt", O_CREAT | O_WRONLY, 0777);
	write(fd, "bhautik", 7);
	write(fd, "kandarpKotadiya", 15);
	close(fd);
	fd = open("sample.txt", O_WRONLY | O_APPEND);
	write(fd, "jidnesh", 4);
}
