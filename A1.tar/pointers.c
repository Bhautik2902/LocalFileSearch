#include<stdio.h>

int main() {
	
	// int a = 5;
	// int *ptr;
	// ptr = &a;

    // int b = 10;
	// ptr = &b;

	// printf("ptr val with *: %d \n", *ptr);
	// printf("ptr val without *: %d \n", ptr);
	// printf("ptr val with &: %d \n", &ptr);

    int *ptr;
	*ptr = 5;
	printf("%d", ptr);
	return 0;
}
