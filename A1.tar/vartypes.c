#include<stdio.h>

void func1();

int main() {
  func1();
  func1();
  return 0;
}

void func1() {
  int a = 5;
  static int b = 5;
  auto int c;
  //extern int d;

  printf("auto variable: %d \n", &c);
  //printf("Extern variable: %d \n", &d);

  a = a+1;
  b = b+1;
  printf("local variable value: %d \n", a);
  printf("static variable val: %d\n", b);
}
